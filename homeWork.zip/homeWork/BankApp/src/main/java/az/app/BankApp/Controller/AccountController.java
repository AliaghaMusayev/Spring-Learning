package az.app.BankApp.Controller;

import az.app.BankApp.model.Account;
import az.app.BankApp.service.AccountService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account")
@AllArgsConstructor
public class AccountController {
    AccountService accountService;

    @PostMapping("/create")
    public Account save(@RequestBody Account account){
        return accountService.save(account);
    }

    @GetMapping("/find/{id}")
    public Account findById(@PathVariable long id){
        return accountService.findById(id);
    }

    @GetMapping("/findAll")
    public List<Account> findAll(){
        return accountService.findAll();
    }

    @PutMapping("/delete/{id}")
    public void deleteById(@PathVariable long id){
        accountService.deleteById(id);
    }
}
