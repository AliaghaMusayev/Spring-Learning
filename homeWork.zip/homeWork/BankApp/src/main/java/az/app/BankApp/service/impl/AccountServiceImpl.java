package az.app.BankApp.service.impl;

import az.app.BankApp.model.Account;
import az.app.BankApp.repository.AccountRepository;
import az.app.BankApp.service.AccountService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class AccountServiceImpl implements AccountService {

    AccountRepository accountRepository;
    @Override
    public Account save(Account account) {
        return accountRepository.save(account);
    }

    @Override
    public Account findById(long id) {
        return accountRepository.findById(id).get();
    }

    @Override
    public List<Account> findAll() {
        return (List<Account>) accountRepository.findAll();
    }

    @Override
    public void deleteById(long id) {
        accountRepository.deleteById(id);
    }

    @Override
    public double increaseBalance(double amount, String iban) {
        return getBalance(iban) + amount;
    }

    @Override
    public double decreaseBalance(double amount, String iban) {
        return getBalance(iban) - amount;
    }

    @Override
    public double getBalance(String iban) {
        return 0;
    }
}
