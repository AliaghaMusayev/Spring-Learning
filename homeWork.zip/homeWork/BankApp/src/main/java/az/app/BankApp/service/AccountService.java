package az.app.BankApp.service;

import az.app.BankApp.model.Account;

import java.util.List;

public interface AccountService {
    Account save(Account account);
    Account findById(long id);
    List<Account> findAll();

    void deleteById(long id);

    double increaseBalance(double amount, String iban);
    double decreaseBalance(double amount, String iban);

    double getBalance(String iban);
}
