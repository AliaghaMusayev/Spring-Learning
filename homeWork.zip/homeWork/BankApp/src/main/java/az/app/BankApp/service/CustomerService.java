package az.app.BankApp.service;

import az.app.BankApp.model.Customer;

import java.util.List;

public interface CustomerService {
    Customer save(Customer customer);
    Customer findById(long id);
    List<Customer> findAll();

    void deleteById(long id);
}
