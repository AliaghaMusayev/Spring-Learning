package az.app.BankApp.Controller;

import az.app.BankApp.model.Customer;
import az.app.BankApp.service.CustomerService;
import lombok.AllArgsConstructor;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customer")
@AllArgsConstructor
public class CustomerController {
    CustomerService customerService;

    @PostMapping("/create")
    public Customer save(@RequestBody Customer customer){
        return customerService.save(customer);
    }

    @GetMapping("/find/{id}")
    public Customer findById(@PathVariable long id){
        return customerService.findById(id);
    }

    @GetMapping("/findAll")
    public List<Customer> findAll(){
        return customerService.findAll();
    }

    @PutMapping("/delete/{id}")
    public void deleteById(@PathVariable long id){
        customerService.deleteById(id);
    }
}
